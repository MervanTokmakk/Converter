import React, { useState } from "react";
function Converter(props) {
  const [input1, setInput1] = useState("");
  const [input2, setInput2] = useState("");

  const handleinput1Change = (e) => {
    const inputValue = e.target.value;
    if (inputValue !== "") {
      setInput1(inputValue);
      const secondValue = props.convertFunction1(inputValue);
      setInput2(secondValue.toFixed(2));
    }
    else {
      setInput1("")
      setInput2("")
    }
  };

  const handleinput2Change = (e) => {
    const inputValue = e.target.value;
    if (inputValue !== "") {
      setInput2(inputValue);
      const secondValue = props.convertFunction2(inputValue);
      setInput1(secondValue.toFixed(2));
    }
    else {
      setInput1("")
      setInput2("")
    }
  };


  return (
    <article>
      <div className="container">
        <div className="row">
          <div className="col-md-6">
            <label className="mt-5 Converter" htmlFor="input 1">{props.unit1}</label>
            <input
              type="number"
              className="form-control labelFix"
              placeholder="Enter convertion..."
              value={input1}
              onChange={handleinput1Change}
            />
          </div>
          <div className="col-md-6">
            <label className="mt-5 Converter" htmlFor="input 2">{props.unit2}</label>
            <input
              type="number"
              className="form-control labelFix "
              placeholder="Enter convertion..."
              value={input2}
              onChange={handleinput2Change}
            />
          </div>
        </div>
      </div>
    </article>

  );
}
export default Converter;

